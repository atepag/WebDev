Please use this link to see the version running the on the school server, I will make the "shuffle pic" button work
Link: http://prism.troy.edu/atepaleaguilar/puzzle/puzzle.html